// 默认配置文件
// 该配置对所有用户生效，修改后需要重新构建项目
export const defaultConfig = {
  hidePtname: true,
  hideRemarks: false,
  hidePass: true,
  hideSchool: false
}