import { createRouter, createWebHistory } from 'vue-router'
import QueryPage from '../views/QueryPage.vue'
import ResultPage from '../views/ResultPage.vue'
import ErrorPage from '../views/ErrorPage.vue'
import AdminLogin from '../views/AdminLogin.vue'
import AdminConfig from '../views/AdminConfig.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'query',
      component: QueryPage
    },
    {
      path: '/result',
      name: 'result',
      component: ResultPage
    },
    {
      path: '/error',
      name: 'error',
      component: ErrorPage
    },
    // 管理员后台路由
    {
      path: '/windame',
      redirect: '/windame/login'
    },
    {
      path: '/windame/login',
      name: 'adminLogin',
      component: AdminLogin
    },
    {
      path: '/windame/config',
      name: 'adminConfig',
      component: AdminConfig
    }
  ]
})

export default router