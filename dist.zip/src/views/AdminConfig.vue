<template>
  <div class="admin-config">
    <div class="config-container">
      <div class="header">
        <h1>项目配置</h1>
        <button @click="handleLogout" class="logout-btn">退出登录</button>
      </div>
      
      <div class="config-content">
        <h2>查询数据展示选项</h2>
        
        <div class="config-options">
          <div class="option-item">
            <input
              type="checkbox"
              id="hidePtname"
              v-model="config.hidePtname"
            />
            <label for="hidePtname">不展示平台名称</label>
          </div>
          
          <div class="option-item">
            <input
              type="checkbox"
              id="hideRemarks"
              v-model="config.hideRemarks"
            />
            <label for="hideRemarks">不展示详细信息</label>
          </div>
          
          <div class="option-item">
            <input
              type="checkbox"
              id="hidePass"
              v-model="config.hidePass"
            />
            <label for="hidePass">不展示密码</label>
          </div>
          
          <div class="option-item">
          <input
            type="checkbox"
            id="hideSchool"
            v-model="config.hideSchool"
          />
          <label for="hideSchool">不展示学校</label>
        </div>
      </div>
      
      <!-- 配置说明 -->
      <div class="config-note">
        <h3>配置说明</h3>
        <p>1. 配置保存后，所有使用同一浏览器访问的用户将看到相同的配置效果</p>
        <p>2. 不同浏览器之间的配置需要分别设置</p>
        <p>3. 配置变更会实时应用到查询结果页面</p>
        <p>4. 当前配置：<br/>{{ JSON.stringify(config, null, 2) }}</p>
        </div>
        
        <div class="action-buttons">
          <button @click="saveConfig" class="save-btn">保存配置</button>
          <button @click="resetConfig" class="reset-btn">重置默认</button>
        </div>
        
        <div class="success-message" v-if="successMsg">
          {{ successMsg }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { defaultConfig } from '../config.js'

const router = useRouter()
const successMsg = ref('')

// 使用配置文件中的默认配置
const config = ref({...defaultConfig})

// 保存配置 - 仅用于演示，实际需要修改config.js文件
const saveConfig = () => {
  successMsg.value = '配置已保存到当前浏览器，如需所有用户生效，请修改 src/config.js 文件'
  setTimeout(() => {
    successMsg.value = ''
  }, 3000)
  
  // 同时保存到当前浏览器的localStorage，方便测试
  localStorage.setItem('queryConfig', JSON.stringify(config.value))
}

// 重置默认配置
const resetConfig = () => {
  config.value = {
    hidePtname: false,
    hideRemarks: false,
    hidePass: false,
    hideSchool: false
  }
  saveConfig()
}

// 退出登录
const handleLogout = () => {
  localStorage.removeItem('adminLoggedIn')
  router.push('/windame/login')
}

// 检查登录状态
const checkLogin = () => {
  const isLoggedIn = localStorage.getItem('adminLoggedIn')
  if (!isLoggedIn) {
    router.push('/windame/login')
  }
}

// 组件挂载时加载配置和检查登录状态
onMounted(() => {
  checkLogin()
})
</script>

<style scoped>
.admin-config {
  display: flex;
  justify-content: center;
  align-items: flex-start;
  min-height: 100vh;
  padding: 20px;
  background-color: #f5f7fa;
  font-family: Arial, sans-serif;
}

.config-container {
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 600px;
  padding: 30px;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
  padding-bottom: 15px;
  border-bottom: 1px solid #f0f0f0;
}

.header h1 {
  font-size: 1.8rem;
  color: #333;
  margin: 0;
}

.logout-btn {
  padding: 8px 16px;
  font-size: 0.9rem;
  background-color: #f56c6c;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.logout-btn:hover {
  background-color: #f78989;
}

.config-content h2 {
  font-size: 1.3rem;
  color: #666;
  margin-bottom: 20px;
}

.config-options {
  background-color: #f9f9f9;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 25px;
}

.option-item {
  display: flex;
  align-items: center;
  margin-bottom: 15px;
  cursor: pointer;
}

.option-item:last-child {
  margin-bottom: 0;
}

.option-item input[type="checkbox"] {
  margin-right: 10px;
  width: 18px;
  height: 18px;
  cursor: pointer;
}

.option-item label {
  font-size: 1rem;
  color: #333;
  cursor: pointer;
}

.action-buttons {
  display: flex;
  gap: 15px;
  margin-bottom: 20px;
}

.save-btn {
  padding: 12px 24px;
  font-size: 1rem;
  background-color: #67c23a;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.save-btn:hover {
  background-color: #85ce61;
}

.reset-btn {
  padding: 12px 24px;
  font-size: 1rem;
  background-color: #909399;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.reset-btn:hover {
  background-color: #a6a9ad;
}

.success-message {
  background-color: #f0f9eb;
  color: #67c23a;
  padding: 12px 15px;
  border-radius: 8px;
  font-size: 0.9rem;
  text-align: center;
}
</style>