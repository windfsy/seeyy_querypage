<template>
  <div class="admin-login">
    <div class="login-container">
      <h1>管理员后台</h1>
      <div class="login-form">
        <div class="form-item">
          <label for="password">密码</label>
          <input
            type="password"
            id="password"
            v-model="password"
            placeholder="请输入管理员密码"
            @keyup.enter="handleLogin"
          />
        </div>
        <button @click="handleLogin" class="login-btn">登录</button>
        <p class="error-message" v-if="errorMsg">{{ errorMsg }}</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const password = ref('')
const errorMsg = ref('')

const handleLogin = () => {
  // 固定密码验证
  if (password.value === '192456') {
    // 保存登录状态到localStorage
    localStorage.setItem('adminLoggedIn', 'true')
    // 跳转到配置页面
    router.push('/windame/config')
  } else {
    errorMsg.value = '密码错误，请重试'
    // 清空密码输入
    setTimeout(() => {
      errorMsg.value = ''
    }, 2000)
  }
}
</script>

<style scoped>
.admin-login {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-color: #f5f7fa;
  font-family: Arial, sans-serif;
}

.login-container {
  background-color: white;
  padding: 40px;
  border-radius: 12px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 400px;
}

h1 {
  font-size: 1.8rem;
  margin-bottom: 30px;
  text-align: center;
  color: #333;
}

.login-form {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.form-item {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.form-item label {
  font-size: 0.9rem;
  font-weight: 500;
  color: #666;
}

.form-item input {
  padding: 12px 15px;
  font-size: 1rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  outline: none;
  transition: border-color 0.3s;
}

.form-item input:focus {
  border-color: #409eff;
}

.login-btn {
  padding: 12px;
  font-size: 1rem;
  background-color: #409eff;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.login-btn:hover {
  background-color: #66b1ff;
}

.error-message {
  color: #f56c6c;
  font-size: 0.9rem;
  text-align: center;
  margin: 0;
}
</style>