<template>
  <div class="query-page">
    <!-- LOGO区域 -->
    <div class="logo-container">
      <img src="../assets/LOGO.jpeg" alt="LOGO" class="logo" />
    </div>
    
    <h1>自助查单</h1>
    <div class="query-form">
      <input
        type="text"
        v-model="phone"
        placeholder="学*通账号（手机号）"
        maxlength="11"
        @keyup.enter="handleSubmit"
      />
      <button @click="handleSubmit">查询</button>
    </div>
    
    <!-- 查询记录区域 -->
    <div class="history-section" v-if="historyList.length > 0">
      <div class="history-header">
        <h3>查询记录</h3>
        <button @click="clearHistory" class="clear-btn">清空</button>
      </div>
      <div class="history-list">
        <div 
          v-for="(item, index) in historyList" 
          :key="index"
          class="history-item"
          @click="quickQuery(item.phone)"
        >
          <span class="phone">{{ item.phone }}</span>
          <span class="time">{{ formatTime(item.time) }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const phone = ref('')
const historyList = ref([])

// 加载查询历史
const loadHistory = () => {
  const history = localStorage.getItem('queryHistory')
  if (history) {
    historyList.value = JSON.parse(history)
  }
}

// 保存查询历史
const saveHistory = (phoneNum) => {
  const historyItem = {
    phone: phoneNum,
    time: Date.now()
  }
  
  // 去重，移除相同手机号的旧记录
  historyList.value = historyList.value.filter(item => item.phone !== phoneNum)
  
  // 添加到最前面
  historyList.value.unshift(historyItem)
  
  // 最多保存10条记录
  if (historyList.value.length > 10) {
    historyList.value = historyList.value.slice(0, 10)
  }
  
  localStorage.setItem('queryHistory', JSON.stringify(historyList.value))
}

// 清空查询历史
const clearHistory = () => {
  if (confirm('确定要清空查询记录吗？')) {
    historyList.value = []
    localStorage.removeItem('queryHistory')
  }
}

// 快速查询历史记录
const quickQuery = (phoneNum) => {
  phone.value = phoneNum
  handleSubmit()
}

// 格式化时间
const formatTime = (timestamp) => {
  const date = new Date(timestamp)
  return date.toLocaleString('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

const handleSubmit = async () => {
  if (!phone.value || phone.value.length !== 11) {
    alert('请输入有效的手机号')
    return
  }

  try {
    console.log('开始请求API...')
    
    // 保存查询历史
    saveHistory(phone.value)
    
    // 简化URL参数，只传递手机号
    router.push({
      name: 'result',
      query: { phone: phone.value }
    })
  } catch (error) {
    console.error('查询失败:', error)
    router.push({
      name: 'error',
      query: { msg: `查询失败: ${error.message}` }
    })
  }
}

// 组件挂载时加载历史记录
onMounted(() => {
  loadHistory()
})
</script>

<style scoped>
.query-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 100vh;
  padding: 20px;
  font-family: Arial, sans-serif;
}

/* LOGO样式 */
.logo-container {
  margin-bottom: 20px;
}

.logo {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  border: 2px solid #409eff;
  object-fit: cover;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

h1 {
  font-size: 2rem;
  margin-bottom: 30px;
  color: #333;
}

.query-form {
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 400px;
  gap: 15px;
}

input {
  padding: 12px 15px;
  font-size: 1rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  outline: none;
  transition: border-color 0.3s;
}

input:focus {
  border-color: #409eff;
}

button {
  padding: 12px;
  font-size: 1rem;
  background-color: #409eff;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #66b1ff;
}

button:active {
  background-color: #3a8ee6;
}

/* 查询记录样式 */
.history-section {
  margin-top: 40px;
  width: 100%;
  max-width: 400px;
}

.history-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.history-header h3 {
  font-size: 1.1rem;
  color: #666;
  margin: 0;
}

.clear-btn {
  padding: 6px 12px;
  font-size: 0.8rem;
  background-color: #f56c6c;
}

.clear-btn:hover {
  background-color: #f78989;
}

.history-list {
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.history-item {
  padding: 12px 15px;
  border-bottom: 1px solid #f0f0f0;
  cursor: pointer;
  transition: background-color 0.2s;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.history-item:last-child {
  border-bottom: none;
}

.history-item:hover {
  background-color: #f5f7fa;
}

.history-item .phone {
  font-weight: 500;
  color: #333;
}

.history-item .time {
  font-size: 0.8rem;
  color: #999;
}
</style>