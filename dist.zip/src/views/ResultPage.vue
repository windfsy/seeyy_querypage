<template>
  <div class="result-page">
    <h1>自助查单结果</h1>
    
    <!-- 快捷查询区域 -->
    <div class="quick-query">
      <input
        type="text"
        v-model="quickPhone"
        placeholder="输入其他手机号查询"
        maxlength="11"
        @keyup.enter="handleQuickQuery"
      />
      <button @click="handleQuickQuery">查询</button>
      <button @click="refreshData" class="refresh-btn">刷新</button>
    </div>
    
    <!-- 加载状态 -->
    <div class="loading" v-if="loading">
      <span>加载中...</span>
    </div>
    
    <!-- 结果列表 -->
    <div class="result-list" v-else>
      <div v-for="item in resultData" :key="item.id" class="result-card">
        <h3>{{ item.kcname }}</h3>
        <div class="card-info">
          <!-- 平台名称 -->
          <div class="info-item" v-if="!config.hidePtname">
            <span class="label">平台名称：</span>
            <span class="value">{{ item.ptname }}</span>
          </div>
          
          <!-- 学校 -->
          <div class="info-item" v-if="!config.hideSchool">
            <span class="label">学校：</span>
            <span class="value">{{ item.school }}</span>
          </div>
          
          <!-- 账号 -->
          <div class="info-item">
            <span class="label">账号：</span>
            <span class="value">{{ item.user }}</span>
          </div>
          
          <!-- 密码 -->
          <div class="info-item" v-if="!config.hidePass">
            <span class="label">密码：</span>
            <span class="value">{{ item.pass }}</span>
          </div>
          
          <!-- 状态 -->
          <div class="info-item">
            <span class="label">状态：</span>
            <span :class="['value', 'status', getStatusClass(item.status)]">{{ item.status }}</span>
          </div>
          
          <!-- 进度 -->
          <div class="info-item">
            <span class="label">进度：</span>
            <span class="value">{{ item.process }}</span>
          </div>
          
          <!-- 详细信息 -->
          <div class="info-item remarks" v-if="!config.hideRemarks">
            <span class="label">详细信息：</span>
            <span class="value">{{ item.remarks }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { defaultConfig } from '../config.js'

const route = useRoute()
const router = useRouter()
const resultData = ref([])
const quickPhone = ref('')
const loading = ref(false)
const currentPhone = ref('')

// 使用配置文件中的默认配置，确保所有用户使用相同的配置
const config = ref({...defaultConfig})

// 根据订单状态返回对应的CSS类
const getStatusClass = (status) => {
  if (status === '进行中') {
    return 'status-blue'
  } else if (status === '已完成') {
    return 'status-green'
  } else if (status === '队列中') {
    return 'status-black'
  }
  return ''
}

// 调用API获取数据
const fetchData = async (phoneNum) => {
  if (!phoneNum || phoneNum.length !== 11) {
    console.error('无效的手机号')
    return
  }

  loading.value = true
  try {
    const response = await fetch('https://bz.benziwk.cn/api/query', {
      method: 'POST',
      headers: {
        'accept': 'application/json, text/plain, */*',
        'content-type': 'application/json;charset=UTF-8',
        'origin': 'https://cd.lovelearn.cc',
        'referer': 'https://cd.lovelearn.cc/',
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15 Edg/142.0.0.0'
      },
      body: JSON.stringify({ username: phoneNum })
    })

    const data = await response.json()
    if (data.code === 1) {
      resultData.value = data.data
    } else {
      router.push({
        name: 'error',
        query: { msg: data.msg }
      })
    }
  } catch (error) {
    console.error('API请求错误:', error)
    router.push({
      name: 'error',
      query: { msg: `查询失败: ${error.message}` }
    })
  } finally {
    loading.value = false
  }
}

// 快捷查询
const handleQuickQuery = () => {
  if (!quickPhone.value || quickPhone.value.length !== 11) {
    alert('请输入有效的手机号')
    return
  }
  
  // 更新URL参数
  router.push({
    name: 'result',
    query: { phone: quickPhone.value }
  })
}

// 刷新当前数据
const refreshData = () => {
  if (currentPhone.value) {
    fetchData(currentPhone.value)
  }
}

// 监听路由参数变化
watch(
  () => route.query.phone,
  (newPhone) => {
    if (newPhone) {
      currentPhone.value = newPhone
      fetchData(newPhone)
    }
  },
  { immediate: true }
)

onMounted(() => {
  console.log('使用的配置:', config.value)
})
</script>

<style scoped>
.result-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 100vh;
  padding: 20px;
  font-family: Arial, sans-serif;
}

h1 {
  font-size: 2rem;
  margin-bottom: 30px;
  color: #333;
}

/* 快捷查询区域样式 */
.quick-query {
  display: flex;
  gap: 10px;
  margin-bottom: 30px;
  width: 100%;
  max-width: 800px;
  flex-wrap: wrap;
}

.quick-query input {
  flex: 1;
  min-width: 200px;
  padding: 10px 15px;
  font-size: 1rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  outline: none;
  transition: border-color 0.3s;
}

.quick-query input:focus {
  border-color: #409eff;
}

.quick-query button {
  padding: 10px 20px;
  font-size: 1rem;
  background-color: #409eff;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s;
  white-space: nowrap;
}

.quick-query button:hover {
  background-color: #66b1ff;
}

.refresh-btn {
  background-color: #67c23a !important;
}

.refresh-btn:hover {
  background-color: #85ce61 !important;
}

/* 加载状态样式 */
.loading {
  margin: 50px 0;
  padding: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.loading span {
  color: #409eff;
  font-size: 1rem;
}

/* 结果列表样式 */
.result-list {
  width: 100%;
  max-width: 800px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.result-card {
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: box-shadow 0.3s;
}

.result-card:hover {
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
}

.result-card h3 {
  margin: 0 0 15px 0;
  font-size: 1.2rem;
  color: #333;
  border-bottom: 1px solid #eee;
  padding-bottom: 10px;
}

.card-info {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.info-item {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
}

.label {
  font-weight: bold;
  color: #666;
  min-width: 80px;
}

.value {
  color: #333;
  word-break: break-word;
}

/* 订单状态颜色 */
.status-blue {
  color: #409eff !important;
  font-weight: bold;
}

.status-green {
  color: #67c23a !important;
  font-weight: bold;
}

.status-black {
  color: #000000 !important;
  font-weight: bold;
}

.remarks {
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px dashed #eee;
}

.remarks .value {
  font-size: 0.9rem;
  line-height: 1.5;
}
</style>