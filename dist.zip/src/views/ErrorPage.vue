<template>
  <div class="error-page">
    <h1>查询错误</h1>
    <div class="error-message">
      {{ errorMsg }}
    </div>
    <button @click="goBack">返回查询页</button>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'

const route = useRoute()
const router = useRouter()
const errorMsg = ref('')

onMounted(() => {
  errorMsg.value = route.query.msg || '查询失败，请稍后重试'
})

const goBack = () => {
  router.push('/')
}
</script>

<style scoped>
.error-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  padding: 20px;
  font-family: Arial, sans-serif;
}

h1 {
  font-size: 2rem;
  margin-bottom: 20px;
  color: #f56c6c;
}

.error-message {
  font-size: 1.1rem;
  color: #666;
  margin-bottom: 30px;
  text-align: center;
  max-width: 500px;
}

button {
  padding: 12px 24px;
  font-size: 1rem;
  background-color: #409eff;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #66b1ff;
}

button:active {
  background-color: #3a8ee6;
}
</style>